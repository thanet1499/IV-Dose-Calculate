# IV Dose Calculator

GitHub Pages-ready package for the uploaded `IVDose Calculator.html`.

## Files
- `index.html` — main application
- `manifest.webmanifest` — PWA configuration
- `sw.js` — service worker for app-shell caching
- `README.md` — this file

## Publish with GitHub Pages
1. Create a GitHub repository (Public is easiest for GitHub Pages).
2. Upload **the files inside this folder** to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**.
6. Save and wait for GitHub Pages to publish.
7. Open the generated `github.io` address in Safari.
8. Use Safari **Share → Add to Home Screen** to install it like an app.

## Important
This package preserves the uploaded calculator as the application source, with only the minimum GitHub/PWA additions (manifest link and service-worker registration).

The calculator contains a Supabase connection and cloud features. Those features require the Supabase project to be configured correctly and secured with appropriate Row Level Security policies.

This is a clinical medication-calculation prototype. Before clinical use, all drug concentrations, dose ranges, preparation instructions, warnings, monitoring information, authentication/authorization, audit trail, and calculations should be reviewed and validated by qualified clinical/pharmacy personnel and according to the local hospital protocol.
